import boto3
import boto3
from botocore.config import Config
from .models import *

# create code for creating instance


# creating aws instance
def create_aws_instance(params):
    client = boto3.client(
        's3',
        aws_access_key_id='AKIAQAS2UWXQJQVWZRSC',
        aws_secret_access_key='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',
        #aws_session_token=SESSION_TOKEN
    )

    resource = boto3.resource(
        'ec2',
        aws_access_key_id='AKIAQAS2UWXQJQVWZRSC',
        aws_secret_access_key='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',
        region_name = 'us-east-1'
    )

    my_config = Config(
        region_name = 'us-east-1',)

    instances = resource.create_instances(
            ImageId=params['aws_image_id'],
            MinCount=1,
            MaxCount=1,
            InstanceType=params['aws_instance_type'],
            KeyName=params['aws_key_name'],
            TagSpecifications=[
        {
            'ResourceType': 'instance',
            'Tags': [
                {
                    'Key': 'Name',
                    'Value': params['instance_name']
                },
            ]
        },
    ],
        )

    instance_id = instances[0].instance_id
    launch_time = instances[0].launch_time


    Instance_object = Instance(
        cloud_provider= params['cloud_provider'],
        flavor=Flavor.objects.get(flavor_name=params['flavor']),
        Image=params['Image'],
        KeyName=params['aws_key_name'],
        instance_name=params['instance_name'],
        team=params['team'],
        program=params['program'],
        users=params['users'],
        contact=params['contact'],
        id_instance=instance_id,
        launch_time=launch_time
    )

    #Instance_object.flavor = Flavor.objects.get(flavor_name=params['flavor'])
    Instance_object.save()



def get_instance_ID(params):
    response = client.describe_instances(
    Filters=[
        {
            'Name': 'tag:Name',
            'Values': [
                params['instance_name'],
            ]
        },
    ],
)


    for r in response['Reservations']:
      for i in r['Instances']:
        instance_id = i['InstanceId']




def delete_instance(params):
    response = client.terminate_instances(
	    InstanceIds=[
        instance_id,],
)



# create openstack instnace
